package com.bmtbima.appbima.adapter

class PengumumanItem {
    var judul: String? = null
    var lampiran : String? = null
    var gambar : Int? = null
}
